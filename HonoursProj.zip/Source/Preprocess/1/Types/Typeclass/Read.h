#pragma once

// UNUSED

#include "MacroUtils.h"

#include "Functional/Prelude.h"
#include "Functional/Typeclass.h"

#include "Types/Unpack.h"


// Functor Interface
class IRead {
};



