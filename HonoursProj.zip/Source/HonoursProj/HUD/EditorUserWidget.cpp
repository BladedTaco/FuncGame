#include "EditorUserWidget.h"

void UEditorUserWidget::ReleaseSlateResources(bool bReleaseChildren) {
	Super::ReleaseSlateResources(bReleaseChildren);
}
