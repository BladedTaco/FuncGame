#pragma once


#ifndef PP__PREPROCESSING

#include "Types/Dataclass/Int_gen.h"
#include "Types/Dataclass/Bool_gen.h"
#include "Types/Dataclass/Char_gen.h"
#include "Types/Dataclass/Float_gen.h"
#include "Types/Dataclass/Func_gen.h"

#else

include "Types/Dataclass/Int_gen.h"
include "Types/Dataclass/Bool_gen.h"
include "Types/Dataclass/Char_gen.h"
include "Types/Dataclass/Float_gen.h"
include "Types/Dataclass/Func_gen.h"

#endif