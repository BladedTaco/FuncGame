﻿#pragma once

// UNUSED

//// Functor Instance Macro
#define READ(INST)		 \
PP__DIRECTIVE(Typeclass, Read, INST)

#include "Read_gen.h"