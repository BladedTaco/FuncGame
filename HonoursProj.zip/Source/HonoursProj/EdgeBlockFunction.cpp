// Fill out your copyright notice in the Description page of Project Settings.


#include "EdgeBlockFunction.h"

AEdgeBlockFunction::AEdgeBlockFunction() {

}

void AEdgeBlockFunction::BeginPlay() {

}
