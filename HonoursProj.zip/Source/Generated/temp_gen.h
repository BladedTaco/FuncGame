.NET Core placeholder content to avoid ignoring the output extension directive


